import { Request, Response, NextFunction } from "express";
import { Form } from "../models/form.model";
import { sendResponse } from "../utils/response";
import { STATUS_CODES } from "../config/constants";
import { Field } from "../models/field.model";
import mongoose from "mongoose";
import { SubCategory } from "../models/category.model";
import { paginateQuery } from "../utils/paginate";
import slugify from "slugify";
import { Dropdown } from "../models/dropdown.model";

export const createNewForm = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const {
      subCategory,
      zone,
      name,
      subTitle,
      price,
      rentalImages,
      description,
      fields,
      language,
      setting,
      context,
      userDocuments,
      leaserDocuments,
    } = req.body;

    // Added new required field validation
    if (
      !name ||
      !subTitle ||
      !price ||
      !rentalImages ||
      !Array.isArray(rentalImages) ||
      rentalImages.length === 0
    ) {
      sendResponse(
        res,
        null,
        "name, subTitle, price, and rentalImages are required",
        STATUS_CODES.BAD_REQUEST
      );
      return;
    }

    // Validate ObjectIds
    if (
      !mongoose.Types.ObjectId.isValid(subCategory) ||
      !mongoose.Types.ObjectId.isValid(zone) ||
      !Array.isArray(fields) ||
      !fields.every((id) => mongoose.Types.ObjectId.isValid(id))
    ) {
      sendResponse(
        res,
        null,
        "Invalid subCategoryId, zoneId or fieldsIds",
        STATUS_CODES.BAD_REQUEST
      );
      return;
    }

    // Check SubCategory exists
    const subCatExists = await SubCategory.findById(subCategory);
    if (!subCatExists) {
      sendResponse(res, null, "SubCategory not found", STATUS_CODES.NOT_FOUND);
      return;
    }

    // Optional: Validate that all fieldIds actually exist
    const validFields = await Field.find({ _id: { $in: fields } });
    if (validFields.length !== fields.length) {
      sendResponse(
        res,
        null,
        "One or more fieldIds are invalid",
        STATUS_CODES.BAD_REQUEST
      );
      return;
    }

    // Validate userDocuments against dropdown
    const userDropdowns = await Dropdown.findOne({ name: "userDocuments" });
    const allowedUserDocs = userDropdowns
      ? userDropdowns.values.map((v) => v.value)
      : [];
    if (userDocuments && Array.isArray(userDocuments)) {
      for (const doc of userDocuments) {
        if (!allowedUserDocs.includes(doc)) {
          sendResponse(
            res,
            null,
            `Invalid user document: ${doc}`,
            STATUS_CODES.BAD_REQUEST
          );
          return;
        }
      }
    }

    // Validate leaserDocuments against dropdown
    const leaserDropdowns = await Dropdown.findOne({ name: "leaserDocuments" });
    const allowedLeaserDocs = leaserDropdowns
      ? leaserDropdowns.values.map((v) => v.value)
      : [];
    if (leaserDocuments && Array.isArray(leaserDocuments)) {
      for (const doc of leaserDocuments) {
        if (!allowedLeaserDocs.includes(doc)) {
          sendResponse(
            res,
            null,
            `Invalid leaser document: ${doc}`,
            STATUS_CODES.BAD_REQUEST
          );
          return;
        }
      }
    }

    // Validate userDocuments inside setting
    if (setting && setting.userDocuments) {
      if (!Array.isArray(setting.userDocuments)) {
        sendResponse(
          res,
          null,
          "userDocuments must be an array",
          STATUS_CODES.BAD_REQUEST
        );
        return;
      }
    }

    const newForm = await Form.create({
      subCategory,
      zone,
      name,
      subTitle,
      price,
      rentalImages,
      description,
      language: language || "en",
      fields,
      setting: setting || {},
      context,
      userDocuments: userDocuments || [],
      leaserDocuments: leaserDocuments || [],
      slug: slugify(name, { lower: true, strict: true }),
    });

    const populatedForm = await Form.findById(newForm._id)
      .populate("fields")
      .populate("zone")
      .populate("subCategory");

    sendResponse(
      res,
      populatedForm,
      "Form created successfully",
      STATUS_CODES.CREATED
    );
  } catch (error) {
    next(error);
  }
};

export const getAllForms = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const lang = (req.query.language || "en").toString().toLowerCase();
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;

    const query =
      lang === "en" ? Form.find({}) : Form.find({ "languages.locale": lang });

    const populatedQuery = query
      .populate("fields")
      .populate("zone")
      .populate("subCategory");

    const paginated = await paginateQuery(populatedQuery, { page, limit });

    const localizedForms = paginated.data.map((form) => {
      const formTranslation = form.languages?.find(
        (entry) => entry.locale?.toLowerCase() === lang
      );

      const zone = form.zone as any;
      const zoneTranslation = zone?.languages?.find(
        (entry: any) => entry.locale?.toLowerCase() === lang
      );
      const localizedZone = zone
        ? {
            ...zone,
            name: zoneTranslation?.translations?.name || zone.name,
          }
        : null;

      const subCat = form.subCategory as any;
      const subCatTranslation = subCat?.languages?.find(
        (entry: any) => entry.locale?.toLowerCase() === lang
      );
      const localizedSubCategory = subCat
        ? {
            ...subCat,
            name: subCatTranslation?.translations?.name || subCat.name,
          }
        : null;

      const localizedFields = Array.isArray(form.fields)
        ? (form.fields as any[]).map((field) => {
            const fieldTranslation = field?.languages?.find(
              (entry: any) => entry.locale?.toLowerCase() === lang
            );
            return {
              ...field,
              name: fieldTranslation?.translations?.name || field.name,
              label: fieldTranslation?.translations?.label || field.label,
              placeholder:
                fieldTranslation?.translations?.placeholder ||
                field.placeholder,
            };
          })
        : [];

      return {
        _id: form._id,
        name: formTranslation?.translations?.name || form.name,
        description:
          formTranslation?.translations?.description || form.description,
        fields: localizedFields,
        zone: localizedZone,
        subCategory: localizedSubCategory,
        language: lang,
      };
    });

    //Send paginated result
    sendResponse(
      res,
      {
        forms: localizedForms,
        total: paginated.total,
        page: paginated.page,
        limit: paginated.limit,
      },
      `Forms found for language: ${lang}`,
      STATUS_CODES.OK
    );
  } catch (error) {
    next(error);
  }
};

export const getFormDetails = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const lang = (req.headers["language"] || "en").toString().toLowerCase();

    const form = await Form.findById(req.params.id)
      .populate("fields")
      .populate("zone")
      .populate("subCategory")
      .lean();

    if (!form) {
      sendResponse(res, null, "Form not found", STATUS_CODES.NOT_FOUND);
      return;
    }

    const formTranslation = form.languages?.find(
      (entry: any) => entry.locale?.toLowerCase() === lang
    );

    const translatedForm: any = {
      ...form,
      name: formTranslation?.translations?.name || form.name,
      description:
        formTranslation?.translations?.description || form.description,
    };

    translatedForm.fields = Array.isArray(form.fields)
      ? (form.fields as any[]).map((field: any) => {
          const fieldTranslation = field.languages?.find(
            (entry: any) => entry.locale?.toLowerCase() === lang
          );
          return {
            ...field,
            name: fieldTranslation?.translations?.name || field.name,
            label: fieldTranslation?.translations?.label || field.label,
            placeholder:
              fieldTranslation?.translations?.placeholder || field.placeholder,
          };
        })
      : [];

    const zone = form.zone as any;
    const zoneTranslation = zone?.languages?.find(
      (entry: any) => entry.locale?.toLowerCase() === lang
    );
    translatedForm.zone = zone
      ? {
          ...zone,
          name: zoneTranslation?.translations?.name || zone?.name || "",
        }
      : null;

    const subCat = form.subCategory as any;
    const subCatTranslation = subCat?.languages?.find(
      (entry: any) => entry.locale?.toLowerCase() === lang
    );
    translatedForm.subCategory = subCat
      ? {
          ...subCat,
          name: subCatTranslation?.translations?.name || subCat?.name || "",
        }
      : null;

    sendResponse(
      res,
      translatedForm,
      `Form details fetched successfully for locale: ${lang}`,
      STATUS_CODES.OK
    );
  } catch (error) {
    next(error);
  }
};

export const getFormByZoneAndSubCategory = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { zone, subCategory } = req.query;
    const lang = (req.query.language || "en").toString().toLowerCase();

    if (!zone || !subCategory) {
      sendResponse(
        res,
        null,
        "zone and subCategory are required",
        STATUS_CODES.BAD_REQUEST
      );
      return;
    }

    if (
      !mongoose.Types.ObjectId.isValid(zone.toString()) ||
      !mongoose.Types.ObjectId.isValid(subCategory.toString())
    ) {
      sendResponse(
        res,
        null,
        "Invalid zone or subCategory",
        STATUS_CODES.BAD_REQUEST
      );
      return;
    }

    const form = await Form.findOne({
      zone,
      subCategory,
    })
      .populate("fields")
      .populate("zone")
      .populate("subCategory")
      .lean();

    if (!form) {
      sendResponse(
        res,
        null,
        "Form not found for given zone and subcategory",
        STATUS_CODES.NOT_FOUND
      );
      return;
    }

    const formTranslation = form.languages?.find(
      (entry: any) => entry.locale?.toLowerCase() === lang
    );
    const zoneObj = form.zone as any;
    const zoneTranslation = zoneObj?.languages?.find(
      (entry: any) => entry.locale?.toLowerCase() === lang
    );

    const subCat = form.subCategory as any;
    const subCatTranslation = subCat?.languages?.find(
      (entry: any) => entry.locale?.toLowerCase() === lang
    );

    const localizedFields = (form.fields as any[]).map((field) => {
      const fieldTranslation = field?.languages?.find(
        (entry: any) => entry.locale?.toLowerCase() === lang
      );

      return {
        ...field,
        name: fieldTranslation?.translations?.name || field.name,
        label: fieldTranslation?.translations?.label || field.label,
        placeholder:
          fieldTranslation?.translations?.placeholder || field.placeholder,
      };
    });

    const localizedForm = {
      ...form,
      name: formTranslation?.translations?.name || form.name,
      description:
        formTranslation?.translations?.description || form.description,
      fields: localizedFields,
      zone: {
        ...zoneObj,
        name: zoneTranslation?.translations?.name || zoneObj.name,
      },
      subCategory: {
        ...subCat,
        name: subCatTranslation?.translations?.name || subCat.name,
      },
      language: lang,
    };

    sendResponse(
      res,
      localizedForm,
      "Form fetched successfully",
      STATUS_CODES.OK
    );
  } catch (error) {
    next(error);
  }
};

export const updateForm = async (req: Request, res: Response) => {
  const { id } = req.params;
  const updateData = req.body;

  const updatedForm = await Form.findByIdAndUpdate(id, updateData, {
    new: true,
  });

  if (!updatedForm) {
    return res.status(404).json({ message: "Form not found" });
  }

  res.status(200).json(updatedForm);
};

export const deleteForm = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const deleted = await Form.findByIdAndDelete(req.params.id);
    if (!deleted) {
      sendResponse(res, null, "Form not found", STATUS_CODES.NOT_FOUND);
      return;
    }
    sendResponse(res, null, "Form deleted successfully", STATUS_CODES.OK);
  } catch (error) {
    next(error);
  }
};

function capitalize(modelName: string): string {
  if (!modelName || typeof modelName !== "string") {
    throw new Error("Invalid model name");
  }
  return modelName.charAt(0).toUpperCase() + modelName.slice(1);
}
